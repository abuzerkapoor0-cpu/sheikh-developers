package com.example.offlinechat

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class ChatMessage(val sender: String, val text: String, val mine: Boolean)

class MessageAdapter : RecyclerView.Adapter<MessageAdapter.VH>() {
    private val items = mutableListOf<ChatMessage>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val bubble: LinearLayout = v.findViewById(R.id.bubble)
        val sender: TextView = v.findViewById(R.id.sender)
        val text: TextView = v.findViewById(R.id.text)
    }

    fun add(m: ChatMessage): Int {
        items.add(m)
        notifyItemInserted(items.lastIndex)
        return items.lastIndex
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val m = items[position]
        h.sender.text = if (m.mine) "You" else m.sender
        h.text.text = m.text
        h.bubble.setBackgroundColor(Color.parseColor(if (m.mine) "#DCF8C6" else "#EEEEEE"))
        (h.bubble.layoutParams as FrameLayout.LayoutParams).gravity =
            if (m.mine) Gravity.END else Gravity.START
    }

    override fun getItemCount() = items.size
}
