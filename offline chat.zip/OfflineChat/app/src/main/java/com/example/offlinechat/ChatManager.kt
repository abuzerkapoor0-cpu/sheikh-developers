package com.example.offlinechat

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy

class ChatManager(
    context: Context,
    private val myName: String,
    private val listener: Listener
) {
    interface Listener {
        fun onStatus(text: String)
        fun onMessage(sender: String, text: String, mine: Boolean)
    }

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context)
    private val strategy = Strategy.P2P_CLUSTER // many-to-many
    private val serviceId = "com.example.offlinechat"

    private val names = mutableMapOf<String, String>()   // endpointId -> display name
    private val connected = linkedSetOf<String>()
    private val pending = mutableSetOf<String>()

    fun start() {
        client.startAdvertising(
            myName, serviceId, connectionCallback,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { listener.onStatus("Advertising failed: ${it.message}") }

        client.startDiscovery(
            serviceId, discoveryCallback,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { listener.onStatus("Discovery failed: ${it.message}") }

        updateStatus()
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        connected.clear(); pending.clear(); names.clear()
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            if (id in connected || !pending.add(id)) return
            client.requestConnection(myName, id, connectionCallback)
                .addOnFailureListener { pending.remove(id) }
        }

        override fun onEndpointLost(id: String) {
            pending.remove(id)
        }
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            names[id] = info.endpointName
            client.acceptConnection(id, payloadCallback)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            pending.remove(id)
            if (result.status.isSuccess) connected.add(id) else names.remove(id)
            updateStatus()
        }

        override fun onDisconnected(id: String) {
            connected.remove(id)
            names.remove(id)
            updateStatus()
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val text = String(bytes, Charsets.UTF_8)
            listener.onMessage(names[id] ?: "Unknown", text, false)
            // TODO: save to a Room database
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    /** Sends to every connected peer (group chat). */
    fun send(message: String) {
        if (connected.isEmpty()) {
            listener.onStatus("No one connected yet — message not sent")
            return
        }
        client.sendPayload(connected.toList(), Payload.fromBytes(message.toByteArray(Charsets.UTF_8)))
        listener.onMessage(myName, message, true)
    }

    private fun updateStatus() {
        listener.onStatus(
            if (connected.isEmpty()) "Searching for nearby devices…"
            else "Connected: ${connected.mapNotNull { names[it] }.joinToString(", ")}"
        )
    }
}
