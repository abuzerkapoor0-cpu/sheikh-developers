package com.example.offlinechat

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), ChatManager.Listener {

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private val adapter = MessageAdapter()
    private var chat: ChatManager? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) askNameAndStart()
            else Toast.makeText(this, "Permissions are required for nearby chat", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        list = findViewById(R.id.messages)
        input = findViewById(R.id.input)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<Button>(R.id.send).setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                chat?.send(text)
                input.text.clear()
            }
        }

        if (chat == null) requestPermissionsThenStart()
    }

    private fun requiredPermissions(): Array<String> {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_ADVERTISE
            p += Manifest.permission.BLUETOOTH_CONNECT
            p += Manifest.permission.BLUETOOTH_SCAN
        } else {
            p += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        return p.toTypedArray()
    }

    private fun requestPermissionsThenStart() {
        val missing = requiredPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) askNameAndStart() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun askNameAndStart() {
        val nameBox = EditText(this).apply { setText(Build.MODEL); setSelectAllOnFocus(true) }
        AlertDialog.Builder(this)
            .setTitle("Your display name")
            .setView(nameBox)
            .setCancelable(false)
            .setPositiveButton("Start") { _, _ ->
                val name = nameBox.text.toString().trim().ifEmpty { Build.MODEL }
                chat = ChatManager(applicationContext, name, this).also { it.start() }
            }
            .show()
    }

    override fun onStatus(text: String) = runOnUiThread { status.text = text }

    override fun onMessage(sender: String, text: String, mine: Boolean) = runOnUiThread {
        val pos = adapter.add(ChatMessage(sender, text, mine))
        list.scrollToPosition(pos)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) chat?.stop()
    }
}
